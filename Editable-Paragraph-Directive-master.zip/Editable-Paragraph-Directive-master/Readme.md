##Editable element as an AngularJS directive##

This directive basically becomes an editable element when the user clicks on it. It goes
back to read-only state once the user click outside the element.

Plunk:
http://plnkr.co/edit/j979NcErHhVmqEoxFm1J